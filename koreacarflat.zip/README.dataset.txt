# korea car plat > 2025-05-22 4:05pm
https://universe.roboflow.com/korean-car-plat/korea-car-plat

Provided by a Roboflow user
License: CC BY 4.0

